import PlaygroundSupport
import UIKit
import AVFoundation
import SoundAnalysis
import SpriteKit

// To collect the current emotion from the recorded voice
var emoDict = ["Angry" : 0,
               "Calm" : 0,
               "Disgust" : 0,
               "Fear" : 0,
               "Happy" : 0,
               "Neutral" : 0,
               "Pleasant Surprise" : 0,
               "Sad" : 0
]

// To collect the total emotion from the recorded voice(s)
var emoHistory = ["Angry" : 0,
                  "Calm" : 0,
                  "Disgust" : 0,
                  "Fear" : 0,
                  "Happy" : 0,
                  "Neutral" : 0,
                  "Pleasant Surprise" : 0,
                  "Sad" : 0
]

// Painting data
struct Paint {
    var red = Double()
    var green = Double()
    var blue = Double()
    var hue = Double()
    var x = Double()
    var y = Double()
}

var red = Double()
var green = Double()
var blue = Double()
var hue = Double()
var coorX = Int()
var coorY = Int()
var recording = true

var paints = [Paint]()

protocol SoundClassifierDelegate {
    func displayPredictionResult(identifier: String, confidence: Double)
}

// To process the result of the classification
class ResultsObserver: NSObject, SNResultsObserving {
    var delegate: SoundClassifierDelegate?
    func request(_ request: SNRequest, didProduce result: SNResult) {
        guard let result = result as? SNClassificationResult,
            let classification = result.classifications.first else { return }
        
        let confidence = classification.confidence * 100.0
        
        if confidence > 60 {
            if classification.identifier != "Background"{
                delegate?.displayPredictionResult(identifier: classification.identifier, confidence: confidence)
                emoDict[classification.identifier] = emoDict[classification.identifier]! + 1
                emoHistory[classification.identifier] = emoHistory[classification.identifier]! + 1
            }
        }
    }
}

// Painter window
class PainterScene : SKScene {
    
    override init() {
        super.init(size: CGSize.zero)
        self.scaleMode = .resizeFill
        self.backgroundColor = .white
        
        let wait = SKAction.wait(forDuration: 0.5)
        let update = SKAction.run(
        {
            // Update color dots
            if recording == false {
                let circle = SKShapeNode(circleOfRadius: 20)
                circle.fillColor = UIColor(red: CGFloat(red), green: CGFloat(green), blue: CGFloat(blue), alpha: 1.0)
                circle.fillColor = UIColor(hue: CGFloat(hue), saturation: 0.7, brightness: 0.5, alpha: 1.0)
                circle.strokeColor = .clear
                self.addChild(circle)
                circle.position = CGPoint(x: coorX, y: coorY)
            }
            }
        )
        let seq = SKAction.sequence([wait,update])
        let repeatAction = SKAction.repeatForever(seq)
        run(repeatAction)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


class MasterViewController: UIViewController,AVAudioRecorderDelegate,AVAudioPlayerDelegate {
    var recordButton = UIButton(type : .system)
    //      var playButton : UIButton!
    var infoButton = UIButton(type: .system)
    var recordingSession: AVAudioSession!
    var voiceRecorder: AVAudioRecorder!
    var voicePlayer: AVAudioPlayer!
    var recordNumber = 1
    let temporaryDirectoryToKeepRecords = FileManager.default.temporaryDirectory
    
    private let audioEngine = AVAudioEngine()
    private var soundClassifier = SoundClassifier()
    var inputFormat: AVAudioFormat!
    var analyzer: SNAudioStreamAnalyzer!
    var resultsObserver = ResultsObserver()
    let analysisQueue = DispatchQueue(label: "com.apple.AnalysisQueue")
    
    var predictionLabel = UILabel()
    //      var idenList = UILabel()
    var infoIsTapped = false
    let infoView = UIView()
    var infoDetailView = UIView()
    var descHeader = UILabel()
    var descBody = UILabel()
    var descFooter = UILabel()
    var emotions = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        
        resultsObserver.delegate = self as SoundClassifierDelegate
        inputFormat = audioEngine.inputNode.inputFormat(forBus: 0)
        analyzer = SNAudioStreamAnalyzer(format: inputFormat)
        
        startAudioEngine()
    }
    
    func setupView(){
        // UI
        let view = UIView()
        view.backgroundColor = .white
        
        let sceneView = SKView(frame: CGRect(x: 0, y: 0, width: 500, height: 500))
        sceneView.presentScene(PainterScene())
        sceneView.layer.borderWidth = 2
        sceneView.layer.cornerRadius = 20.0
        sceneView.layer.borderColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
        
        infoView.backgroundColor = .white
        infoView.layer.cornerRadius = 20.0
        UIView.animate(withDuration: 0.8, delay: 0.1, options: .curveEaseOut, animations: {
            self.infoView.alpha = 0.0
        }, completion: nil)
        
        infoDetailView.layer.cornerRadius = 20.0
        UIView.animate(withDuration: 0.8, delay: 0.1, options: .curveEaseOut, animations: {
            self.infoDetailView.alpha = 0.0
        }, completion: nil)
        
        recordButton = UIButton(type: .system)
        recordButton.tintColor = .white
        recordButton.backgroundColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
        recordButton.addTarget(self, action: #selector(recordButtonTapped), for: .touchUpInside)
        recordButton.layer.cornerRadius = 100.0
        recordButton.setImage(#imageLiteral(resourceName: "Group@3x.png"), for: .normal)
        recordButton.imageView?.contentMode = .scaleAspectFit
        recordButton.imageEdgeInsets = UIEdgeInsets(top: 50, left: 50, bottom: 50, right: 50)
        
        infoButton = UIButton(type: .system)
        infoButton.setTitle("i", for: .normal)
        infoButton.titleLabel?.font = UIFont(name: "HelveticaNeue", size: 25)
        infoButton.tintColor = .white
        infoButton.backgroundColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
        infoButton.layer.borderWidth = 2
        infoButton.layer.borderColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
        infoButton.addTarget(self, action: #selector(infoButtonTapped), for: .touchUpInside)
        infoButton.layer.cornerRadius = 25.0
        
        let boldAttribute = [
            NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 20.0)
        ]
        let regularAttribute = [
            NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Light", size: 20.0)
        ]
        
        predictionLabel.text = "Let's share some of your thoughts\nIt's okay to let some of it out"
        predictionLabel.textColor = .black
        predictionLabel.numberOfLines = 2
        predictionLabel.textAlignment = .center
        predictionLabel.font = UIFont(name: "HelveticaNeue", size: 25)
        
        descHeader.text = "You've passed all these emotions"
        descHeader.textColor = .black
        descHeader.numberOfLines = 2
        descHeader.textAlignment = .center
        descHeader.font = UIFont(name: "HelveticaNeue-Bold", size: 25)
        
        descBody.textColor = .black
        descBody.numberOfLines = 10
        descBody.textAlignment = .center
        descBody.font = UIFont(name: "HelveticaNeue", size: 16)
        
        let footer = NSMutableAttributedString()
        footer.append(NSAttributedString(string:  "Every each of the dots represents ", attributes: regularAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  "one of your story ", attributes: boldAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  "with all of your mixed emotions in it.\nThis is ", attributes: regularAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  "the portrait of your emotions", attributes: boldAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  ", it's beautiful.\nIt's okay to feel all of those things, after all ", attributes: regularAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  "we’re all just a normal human being", attributes: boldAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  ".\nThanks for sharing your emotions with me, ", attributes: regularAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  "you’re not alone", attributes: boldAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  ".\nYou can share this portrait to anyone, because ", attributes: regularAttribute as [NSAttributedString.Key : Any]))
        footer.append(NSAttributedString(string:  "you are the artist of your own emotion portrait.", attributes: boldAttribute as [NSAttributedString.Key : Any]))
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 4
        footer.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, footer.length))
        
        descFooter.attributedText = footer
        descFooter.textColor = .black
        descFooter.numberOfLines = 10
        descFooter.textAlignment = .center
        
        view.addSubview(recordButton)
        view.addSubview(predictionLabel)
        view.addSubview(sceneView)
        view.addSubview(infoButton)
        view.addSubview(infoView)
        view.addSubview(infoDetailView)
        infoDetailView.addSubview(descHeader)
        infoDetailView.addSubview(descBody)
        infoDetailView.addSubview(descFooter)
        
        // Layout
        recordButton.translatesAutoresizingMaskIntoConstraints = false
        predictionLabel.translatesAutoresizingMaskIntoConstraints = false
        sceneView.translatesAutoresizingMaskIntoConstraints = false
        infoButton.translatesAutoresizingMaskIntoConstraints = false
        infoView.translatesAutoresizingMaskIntoConstraints = false
        infoDetailView.translatesAutoresizingMaskIntoConstraints = false
        descHeader.translatesAutoresizingMaskIntoConstraints = false
        descBody.translatesAutoresizingMaskIntoConstraints = false
        descFooter.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            recordButton.widthAnchor.constraint(equalToConstant: 200),
            recordButton.heightAnchor.constraint(equalToConstant: 200),
            recordButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            recordButton.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 350),
            
            predictionLabel.widthAnchor.constraint(equalToConstant: 500),
            predictionLabel.heightAnchor.constraint(equalToConstant: 150),
            predictionLabel.topAnchor.constraint(equalTo: recordButton.topAnchor, constant: -150),
            predictionLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            
            descHeader.widthAnchor.constraint(equalToConstant: 450),
            descHeader.topAnchor.constraint(equalTo: infoDetailView.topAnchor, constant: 20),
            descHeader.centerXAnchor.constraint(equalTo: infoDetailView.centerXAnchor, constant: 0),
            
            descBody.widthAnchor.constraint(equalToConstant: 450),
            descBody.topAnchor.constraint(equalTo: descHeader.bottomAnchor, constant: 8),
            descBody.centerXAnchor.constraint(equalTo: infoDetailView.centerXAnchor, constant: 0),
            
            descFooter.widthAnchor.constraint(equalToConstant: 450),
            descFooter.bottomAnchor.constraint(equalTo: infoDetailView.bottomAnchor, constant: -20),
            descFooter.centerXAnchor.constraint(equalTo: infoDetailView.centerXAnchor, constant: 0),
            
            infoButton.widthAnchor.constraint(equalToConstant: 50),
            infoButton.heightAnchor.constraint(equalToConstant: 50),
            infoButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 50),
            infoButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            
            sceneView.widthAnchor.constraint(equalToConstant: 500),
            sceneView.heightAnchor.constraint(equalToConstant: 500),
            sceneView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            sceneView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -150),
            
            infoView.widthAnchor.constraint(equalToConstant: 500),
            infoView.heightAnchor.constraint(equalToConstant: 500),
            infoView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            infoView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -150),
            
            infoDetailView.widthAnchor.constraint(equalToConstant: 500),
            infoDetailView.heightAnchor.constraint(equalToConstant: 500),
            infoDetailView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            infoDetailView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -150),
        ])
        
        self.view = view
    }
    
    // Calculate emotions to appear
    func emotionsToAppear() {
        emotions = ""
        for key in emoHistory.keys{
            if emoHistory[key]! > 0 {
                emotions.append("\(key)\n")
            }
        }
        descBody.text = emotions
    }
    
    
    // Calculate color based on emotion prediction
    func colorCalculation() {
        red = Double(emoDict["Angry"] ?? 0) + Double(emoDict["Fear"]!) + Double(emoDict["Disgust"] ?? 0)
        red = (red.truncatingRemainder(dividingBy : 10) ) / 10
        green = Double(emoDict["Happy"] ?? 0) + Double(emoDict["Pleasant Surprised"] ?? 0)
        green = (green.truncatingRemainder(dividingBy : 10) ) / 10
        blue = Double(emoDict["Calm"] ?? 0) + Double(emoDict["Neutral"]!) + Double(emoDict["Sad"] ?? 0)
        blue = (blue.truncatingRemainder(dividingBy : 10) ) / 10
        
        hue = Double(emoDict["Calm"] ?? 0) + Double(emoDict["Happy"]!) + Double(emoDict["Angry"] ?? 0)
        hue = (hue.truncatingRemainder(dividingBy : 10) ) / 10
    }
    
    // Voice record button action
    @objc func recordButtonTapped(){
        print("record button is tapped")
        if voiceRecorder == nil {
            recordNumber += 1
            
            let recordFileName = temporaryDirectoryToKeepRecords.appendingPathComponent("record\(recordNumber).m4a")
            
            recordButton.setImage(#imageLiteral(resourceName: "Rectangle@3x.png"), for: .normal)
            recordButton.imageEdgeInsets = UIEdgeInsets(top: 70, left: 70, bottom: 70, right: 70)
            let settings = [AVFormatIDKey: Int(kAudioFormatMPEG4AAC), AVSampleRateKey: 44100, AVNumberOfChannelsKey: 1, AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue]
            recordingSession = AVAudioSession.sharedInstance()
            do {
                
                try recordingSession.setCategory(.playAndRecord, mode: .default)
                try recordingSession.setActive(true, options: [])
                voiceRecorder = try AVAudioRecorder(url: recordFileName, settings: settings)
                emoDict.keys.forEach{emoDict[$0] = 0}
                voiceRecorder.record()
                recording = true
                
                // Randomize the coordinate
                coorX = Int.random(in: 0...500)
                coorY = Int.random(in: 0...500)
                
                // Store in struct
                paints.append(Paint(red: red, green: green, blue: blue, hue: hue, x: Double(coorX), y: Double(coorY)))
                do{
                    try audioEngine.start()
                }catch( _){
                    print("error in starting the Audio Engine")
                }
            } catch {
                print(error)
            }
        } else {
            recordButton.setImage(#imageLiteral(resourceName: "Group@3x.png"), for: .normal)
            recordButton.imageEdgeInsets = UIEdgeInsets(top: 50, left: 50, bottom: 50, right: 50)
            voiceRecorder.stop()
            audioEngine.stop()
            colorCalculation()
            recording = false
            voiceRecorder = nil
            predictionLabel.text = "Let's share some of your thoughts\nIt's okay to let some of it out"
            emotionsToAppear()
        }
    }
    
    @objc func infoButtonTapped() {
        infoIsTapped = !infoIsTapped
        if infoIsTapped == true {
            UIView.animate(withDuration: 0.8, delay: 0.1, options: .curveEaseOut, animations: {
                self.infoView.alpha = 0.6
            }, completion: nil)
            UIView.animate(withDuration: 0.8, delay: 0.1, options: .curveEaseOut, animations: {
                self.infoDetailView.alpha = 1.0
            }, completion: nil)
            infoButton.backgroundColor = .white
            infoButton.layer.borderColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
            infoButton.layer.borderWidth = 2
            infoButton.tintColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
        }else{
            UIView.animate(withDuration: 0.8, delay: 0.1, options: .curveEaseOut, animations: {
                self.infoView.alpha = 0.0
            }, completion: nil)
            UIView.animate(withDuration: 0.8, delay: 0.1, options: .curveEaseOut, animations: {
                self.infoDetailView.alpha = 0.0
            }, completion: nil)
            infoButton.backgroundColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
            infoButton.layer.borderColor = #colorLiteral(red: 0.3098039329, green: 0.01568627544, blue: 0.1294117719, alpha: 1)
            infoButton.layer.borderWidth = 2
            infoButton.tintColor = .white
        }
        
        
    }
    
    // Function to start the analyzer
    private func startAudioEngine() {
        do {
            let request = try SNClassifySoundRequest(mlModel: soundClassifier.model)
            try analyzer.add(request, withObserver: resultsObserver)
        } catch {
            print("Unable to prepare request: \(error.localizedDescription)")
            return
        }
        
        audioEngine.inputNode.installTap(onBus: 0, bufferSize: 8000, format: inputFormat) { buffer, time in
            self.analysisQueue.async {
                self.analyzer.analyze(buffer, atAudioFramePosition: time.sampleTime)
            }
        }
    }
}

// To display the prediction
extension MasterViewController: SoundClassifierDelegate {
    func displayPredictionResult(identifier: String, confidence: Double) {
        DispatchQueue.main.async {
            let prediction = NSMutableAttributedString()
            prediction.append(NSAttributedString(string:  "From what I've heard\nYou are feeling ", attributes: [
                NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Light", size: 25.0)
            ]))
            prediction.append(NSAttributedString(string:  "\(identifier)", attributes: [
                NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 25.0)
            ]))
            self.predictionLabel.attributedText = prediction
        }
    }
}

let master = MasterViewController()
PlaygroundPage.current.liveView = master


